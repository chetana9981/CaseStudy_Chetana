package com.bookutil;

import java.util.Scanner;

import com.book.Book;
import com.book.Exception.InvalidBookException;

public class BookUtil {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String bookID;
		String title;
		String author;
		String category;
		float price;
		
		
		Book b;
		for (int i = 0; i < 2; i++) { 
			
			System.out.println("Enter bookid = ");
			bookID = sc.nextLine();
			
			System.out.println("Enter title = ");
			title = sc.nextLine();
			
			System.out.println("Enter author = ");
			author = sc.nextLine();
			
			System.out.println("Enter category = ");
			category = sc.nextLine();
			
			System.out.println("Enter price = ");
			price = sc.nextFloat();
			
			
			try {
				b = new Book(bookID, title, author, category, price);
			} catch (InvalidBookException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			b
			
		}
		
		
		
	}

}
