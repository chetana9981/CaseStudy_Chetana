package com.book;

import com.book.Exception.InvalidBookException;

public class Book {
	
	//create members
	
	private String bookID;
	private String title;
	private String author;
	private String category;
	private float price;
	
	
	//creating getters and setters
	
	//getter for bookID
	public String getbookID()
	{
		return bookID;
	}
	
	//getter for title
		public String gettitle()
		{
			return title;
		}
		
	//getter for author
		public String getauthor()
		{
			return author;
		}
	
	//getter for category
		public String getcategory()
		{
			return category;
		}
			
	//getter for price
		public float getprice()
		{
			return  price;
		}

	
		
		//setter for bookID
		public void setbookID(String bookID) {
			
			if(bookID.length()> 4 && bookID.startsWith("B")) {
				System.out.println("The conditions required are not met");
			}
			
			else { 
			this.bookID=bookID;
			}
		}

		
		//setter for price
		public void setprice(float price) {
			
			if(price<=0) {
				System.out.println("The price should not be negative");
			}
			
			else {
				this.price=price;
			}
		}	
		
		
		@Override
		public String toString() {
			return "Book [bookID=" + bookID + ", title=" + title + ", author=" + author + ", category=" + category + ", price="
					+ price + "]";
		}
		
	//setter for category
		
	public void setcategory(String option) {
		
		if(option == "Science")
			this.category = option;
		
		else if(option == "Fiction")
			this.category = option;
		
		else if(option == "Technology")
			this.category = option;
		
		else if(option == "Others")
			this.category = option;
		
		else
			System.out.println("Book doesn't come under the required category");
		
	}
		
	
	
	public Book() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	// parameterized constructor
	
	

	public Book(String bookID, String title, String author, String category, float price) throws InvalidBookException {
		
		super();
		
		// validation for price
				if(price <= 0)
					throw new InvalidBookException();
				
				// validation for bookID
				if(bookID.length() > 4 && bookID.startsWith("B"))
					throw new InvalidBookException();
				
				// validation for category
				if(category != "Science"|| category != "Fiction"||category != "Technology"||category != "Others")
					throw new InvalidBookException();
				
				
				this.bookID = bookID;
				this.title = title;
				this.author = author;
				this.category = category;
				this.price = price;
				

		
	}

	
}
