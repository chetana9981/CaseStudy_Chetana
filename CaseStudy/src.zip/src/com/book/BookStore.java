package com.book;

import java.util.ArrayList;
import java.util.List;

public class BookStore {
	
	List<Book> bookStoreList = new ArrayList<Book>();
	
	public static void addBook(Book b)
	{
		
		bookStoreList.add(b);
						
	}
	
	
	
	
	public static void searchByTitle(String title)
	{
		for (Book book : bookStoreList) {
			
			if (book.gettitle().equals(title)) {
				System.out.println(book.toString());
				return;
				
			}
			
		}
		
		System.out.println("Record not found");
	
		
	}
	
	
	
	public static void searchByAuthor(String author)
	{
		for (Book book : bookStoreList) {
			
			if (book.getauthor().equals(author)) {
				System.out.println(book.toString());
				return;
			
				
			}
			
		}
		System.out.println("Record not found");

		
	
		
	}
	
	
	
	public static void displayAll()
	{
		for (Book book : bookStoreList) {
			System.out.println(book.toString());
		}
	}
	
	
	
	
	
}
